import numpy as np


def load_ucr_dataset(train_path):
    """
    Load UCR time series dataset from a text file.
    """
    data_train = np.loadtxt(train_path)
    y_train = data_train[:, 0].astype(int)
    X_train = data_train[:, 1:]
    return X_train, y_train


def get_class_info(y):
    """
    Analyse class distribution and identify majority / minority classes.
    """
    unique_labels, class_counts = np.unique(y, return_counts=True)
    majority_idx = np.argmax(class_counts)
    minority_idx = np.argmin(class_counts)

    return {
        "unique_labels": unique_labels,
        "class_counts": class_counts,
        "majority_class": unique_labels[majority_idx],
        "minority_class": unique_labels[minority_idx],
        "imbalance_ratio": class_counts[majority_idx] / class_counts[minority_idx],
    }


def extract_minority_samples(X, y, minority_class):
    """
    Extract samples belonging to the minority class.
    """
    minority_indices = np.where(y == minority_class)[0]
    return X[minority_indices], y[minority_indices], minority_indices