import numpy as np
import random

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)

def dtw_distance(ts1, ts2):
    """
    Compute the DTW distance between two time series together with the
    optimal warping path and the per-step movement directions.
    """
    n, m = len(ts1), len(ts2)

    cost_matrix = np.zeros((n, m))
    for i in range(n):
        for j in range(m):
            cost_matrix[i, j] = abs(ts1[i] - ts2[j])

    dtw_matrix = np.zeros((n, m))
    dtw_matrix[0, 0] = cost_matrix[0, 0]

    for i in range(1, n):
        dtw_matrix[i, 0] = cost_matrix[i, 0] + dtw_matrix[i - 1, 0]

    for j in range(1, m):
        dtw_matrix[0, j] = cost_matrix[0, j] + dtw_matrix[0, j - 1]

    for i in range(1, n):
        for j in range(1, m):
            dtw_matrix[i, j] = cost_matrix[i, j] + min(
                dtw_matrix[i - 1, j],
                dtw_matrix[i, j - 1],
                dtw_matrix[i - 1, j - 1],
            )
    path = []
    directions = []
    i, j = n - 1, m - 1
    path.append((i, j))

    while i > 0 or j > 0:
        if i == 0:
            j -= 1
            directions.append(1)
        elif j == 0:
            i -= 1
            directions.append(2)
        else:
            min_val = min(
                dtw_matrix[i - 1, j],
                dtw_matrix[i, j - 1],
                dtw_matrix[i - 1, j - 1],
            )
            if dtw_matrix[i - 1, j - 1] == min_val:
                i -= 1
                j -= 1
                directions.append(0)
            elif dtw_matrix[i - 1, j] == min_val:
                i -= 1
                directions.append(2)
            else:
                j -= 1
                directions.append(1)

        path.append((i, j))

    path.reverse()
    directions.reverse()

    return dtw_matrix[n - 1, m - 1], path, directions


def WSMOTE(
    D_minority,
    y_minority,
    X_all,
    y_all,
    k=3,
    diagonal_weight=0.7,
    linear_weight=1.4,
    seed=42,
):
    set_seed(seed)

    D_minority = np.array(D_minority)
    y_minority = np.array(y_minority)
    X_all = np.array(X_all)
    y_all = np.array(y_all)

    D_prime = []
    n_minority, seq_length = D_minority.shape

    for i, p in enumerate(D_minority):
        distances_all = []
        for j in range(len(X_all)):
            if not np.array_equal(X_all[j], p):
                dist, _, _ = dtw_distance(p, X_all[j])
                distances_all.append((j, dist))
        distances_all.sort(key=lambda x: x[1])
        knn_indices = [idx for idx, _ in distances_all[:k]]
        minority_knn = [
            idx for idx in knn_indices if y_all[idx] == y_minority[i]
        ]
        if not minority_knn:
            continue
        n_idx = random.choice(minority_knn)
        n = X_all[n_idx]
        sl_p = np.sum(y_all[knn_indices] == y_minority[i])

        distances_all_n = []
        for j in range(len(X_all)):
            if not np.array_equal(X_all[j], n):
                dist, _, _ = dtw_distance(n, X_all[j])
                distances_all_n.append((j, dist))
        distances_all_n.sort(key=lambda x: x[1])
        knn_n_indices = [idx for idx, _ in distances_all_n[:k]]
        sl_n = np.sum(y_all[knn_n_indices] == y_all[n_idx])

        if sl_n == 0:
            sl_ratio = float("inf")
        else:
            sl_ratio = sl_p / sl_n

        if sl_ratio == float("inf"):
            if sl_p == 0:
                continue
            else:
                D_prime.append(p.copy())
                continue
        elif sl_ratio == 1:
            gap = random.random()
        elif sl_ratio > 1:
            gap = random.uniform(0, 1 / sl_ratio)
        else:
            gap = random.uniform(1 - sl_ratio, 1)

        _, path, directions = dtw_distance(p, n)
        joint_length = len(path)

        aligned_p = np.zeros(joint_length)
        aligned_n = np.zeros(joint_length)
        synthetic_joint = np.zeros(joint_length)

        for idx, (pi, pj) in enumerate(path):
            aligned_p[idx] = p[pi]
            aligned_n[idx] = n[pj]

        for idx in range(joint_length):
            current_gap = gap
            if idx > 0:
                dir_type = directions[idx - 1]
                if dir_type == 0:
                    current_gap = gap * diagonal_weight
                else:
                    current_gap = gap * linear_weight
                current_gap = max(0.0, min(1.0, current_gap))
            synthetic_joint[idx] = (
                (1 - current_gap) * aligned_p[idx] + current_gap * aligned_n[idx]
            )

        x_old = np.linspace(0, 1, joint_length)
        x_new = np.linspace(0, 1, seq_length)
        synthetic = np.interp(x_new, x_old, synthetic_joint)

        D_prime.append(synthetic)

    return np.array(D_prime)