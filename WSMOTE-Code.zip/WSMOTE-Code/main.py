import numpy as np
from data_loader import load_ucr_dataset, get_class_info, extract_minority_samples
from WSMOTE import WSMOTE

def main():
    train_path = "ECG200_TRAIN.txt"

    X_train, y_train = load_ucr_dataset(train_path)

    info = get_class_info(y_train)
    majority_class = info["majority_class"]
    minority_class = info["minority_class"]
    unique_labels  = info["unique_labels"]
    class_counts   = info["class_counts"]

    print("Dataset: ECG200 (warped, alpha=0.4)")
    print(f"Majority class : {majority_class}  samples: {class_counts[np.argmax(class_counts)]}")
    print(f"Minority class : {minority_class}  samples: {class_counts[np.argmin(class_counts)]}")
    print(f"Imbalance ratio: {info['imbalance_ratio']:.1f}:1")

    # Extract minority samples
    X_minority, y_minority, minority_indices = extract_minority_samples(
        X_train, y_train, minority_class
    )

    # Generate synthetic samples
    print("\nGenerating synthetic samples (path-aware weight adjustment)...")
    S_synthetic = WSMOTE(
        X_minority, y_minority,
        X_train, y_train,
        k=3,
        diagonal_weight=0.7,
        linear_weight=1.4,
        seed=42,
    )
    print(f"Generated {len(S_synthetic)} synthetic samples.")

    # Build balanced dataset
    X_train_balanced = np.vstack([X_train, S_synthetic])
    y_train_balanced = np.hstack(
        [y_train, np.full(len(S_synthetic), minority_class)]
    )

    # Save
    np.savez(
        "ECG200_WSMOTE.npz",
        X_train=X_train_balanced,
        y_train=y_train_balanced,
    )
    print("Balanced dataset saved to ECG200_WSMOTE.npz")

    balanced_counts = np.unique(y_train_balanced, return_counts=True)[1]
    print("\nClass distribution summary:")
    print(f"{'Class':<10} {'Original':<15} {'Augmented':<15} {'Growth':<10}")
    for i, label in enumerate(unique_labels):
        original_count = class_counts[i]
        balanced_count = balanced_counts[i]
        growth = (balanced_count - original_count) / original_count * 100
        print(f"{label:<10} {original_count:<15} {balanced_count:<15} {growth:.1f}%")

if __name__ == "__main__":
    main()